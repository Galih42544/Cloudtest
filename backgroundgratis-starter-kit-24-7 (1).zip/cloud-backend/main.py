"""
SERVER CLOUD 24/7 GRATIS (PYTHON FASTAPI)
Deploy gratis ke Render.com / Koyeb / Railway
"""

from fastapi import FastAPI, Request
from pydantic import BaseModel
from typing import Optional, Dict
import datetime
import os
import uvicorn

app = FastAPI(title="BackgroundGratis Cloud Backend")

server_stats = {
    "boot_time": datetime.datetime.utcnow().isoformat(),
    "total_heartbeats": 0,
    "total_pings": 0,
    "last_heartbeat": None,
    "last_ping": None,
    "devices": {}
}

class HeartbeatPayload(BaseModel):
    source: Optional[str] = "Android-APK"
    status: Optional[str] = "ONLINE"
    deviceInfo: Optional[str] = None
    timestamp: Optional[str] = None

@app.get("/")
def read_root():
    return {
        "status": "ONLINE",
        "service": "BackgroundGratis",
        "message": "Server FastAPI Cloud Aktif 24/7!",
        "stats": server_stats
    }

@app.get("/ping")
def ping_keepalive():
    server_stats["total_pings"] += 1
    server_stats["last_ping"] = datetime.datetime.utcnow().isoformat()
    return "PONG - SERVER ACTIVE 24/7"

@app.get("/health")
def health_check():
    return {"status": "healthy", "timestamp": datetime.datetime.utcnow().isoformat()}

@app.post("/api/heartbeat")
def receive_heartbeat(data: HeartbeatPayload):
    server_stats["total_heartbeats"] += 1
    now = datetime.datetime.utcnow().isoformat()
    server_stats["last_heartbeat"] = now
    
    if data.deviceInfo:
        server_stats["devices"][data.deviceInfo] = now
        
    return {
        "success": True,
        "message": "Heartbeat diterima dari " + (data.source or "APK"),
        "server_time": now
    }

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 3000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
