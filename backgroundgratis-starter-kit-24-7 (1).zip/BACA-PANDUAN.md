# Cetak Biru Lengkap: APK Android Background 24/7 + Cloud Server Gratis

Sistem ini terdiri dari dua bagian terintegrasi:
1. **Folder /android-app**: Proyek aplikasi Android dengan Foreground Service & START_STICKY.
2. **Folder /cloud-backend**: Web service siap deploy ke Render.com (gratis) + Anti-Sleep Pinger.

---

## Langkah 1: Deploy Server Cloud Gratis (Render.com)
1. Buat akun di https://render.com (Gratis).
2. Buat repositori baru di GitHub Anda dan masukkan isi folder `/cloud-backend`.
3. Di dashboard Render, klik **New +** -> **Web Service**.
4. Hubungkan repo GitHub Anda.
5. Konfigurasi:
   - **Environment**: Python 3
   - **Build Command**: pip install -r requirements.txt
   - **Start Command**: uvicorn main:app --host 0.0.0.0 --port $PORT
   - **Plan**: Free (Gratis $0/bln)
6. Klik **Create Web Service**. Tunggu 1-2 menit hingga status menjadi **Live**.
7. Salin URL server Anda (contoh: https://backgroundgratis.onrender.com).

---

## Langkah 2: Aktifkan Anti-Sleep Pinger (Agar Cloud Tidak Tertidur)
*Render versi gratis akan otomatis tertidur jika 15 menit sepi pengunjung. Ini solusinya:*
1. Buka https://uptimerobot.com lalu daftar akun gratis.
2. Klik **Add New Monitor**.
3. **Monitor Type**: HTTP(s)
4. **Friendly Name**: Server Cloud 24/7
5. **URL (or IP)**: URL Render Anda + `/ping` (contoh: `https://cloudfree.onrender.com/ping`)
6. **Monitoring Interval**: 5 minutes (5 menit)
7. Simpan monitor. UptimeRobot sekarang akan menembak server Anda setiap 5 menit sehingga server tetap MELEK 24/7 nonstop!

---

## Langkah 3: Build & Jalankan APK Android
1. Buka Android Studio -> **Open an Existing Project** -> Arahkan ke folder `/android-app`.
2. Pastikan file `LayananLatarBelakang.kt` sudah mengarah ke URL Cloud Render Anda.
3. Sambungkan HP Android atau emulator, lalu tekan **Run (Shift + F10)**.
4. Di HP:
   - Buka aplikasi dan tekan tombol **Izinkan Notifikasi**.
   - Tekan tombol **Abaikan Optimasi Baterai** -> Pilih **Jangan Optimalkan (Unrestricted)**.
   - Tekan tombol **Mulai Layanan Foreground**.
5. Notifikasi persisten akan muncul di bar notifikasi, dan data akan disinkronkan ke Cloud secara konsisten tanpa takut dimatikan OS!

Selamat membangun sistem tanpa biaya operasional (Rp 0)!
