package com.app.backgroundgratis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Timer
import java.util.TimerTask
import java.util.Date

class LayananLatarBelakang : Service() {

    private val CHANNEL_ID = "SaluranLatarBelakangNonstop"
    private val NOTIFICATION_ID = 1001
    private var timer: Timer? = null

    override fun onCreate() {
        super.onCreate()
        buatNotificationChannel()

        // Tampilkan notifikasi persisten agar diakui sebagai Foreground Service
        val notification = bangunNotifikasi("Aplikasi sedang berjalan aman di latar belakang.")
        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Jalankan timer pengiriman data ke Cloud
        mulaiTugasLatarBelakang()

        /**
         * KUNCI KEBERHASILAN #1: START_STICKY
         * Jika Android kehabisan RAM dan terpaksa mematikan service ini,
         * sistem operasi akan otomatis menciptakan kembali (re-create) service
         * saat sumber daya memori tersedia lagi!
         */
        return START_STICKY
    }

    private fun mulaiTugasLatarBelakang() {
        // Bersihkan timer lama jika ada
        timer?.cancel()
        timer = Timer()

        val intervalMs = 10 * 1000L

        timer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                kirimDataKeCloudServer()
            }
        }, 0, intervalMs)
    }

    private fun kirimDataKeCloudServer() {
        Thread {
            try {
                val endpointUrl = "https://cloudfree.onrender.com/api/heartbeat"
                val url = URL(endpointUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")

                val payload = """
                    {
                        "source": "Android-Foreground-APK",
                        "status": "ONLINE",
                        "timestamp": "${Date()}",
                        "deviceInfo": "${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})"
                    }
                """.trimIndent()

                OutputStreamWriter(conn.outputStream).use { writer ->
                    writer.write(payload)
                    writer.flush()
                }

                val responseCode = conn.responseCode
                println("[BackgroundGratis] Heartbeat terkirim ke cloud -> Kode Respon: $responseCode")
                conn.disconnect()
            } catch (e: Exception) {
                println("[BackgroundGratis] Gagal koneksi cloud: ${e.message} (Akan dicoba lagi pada siklus berikutnya)")
            }
        }.start()
    }

    private fun bangunNotifikasi(pesan: String): Notification {
        val intentBukaApp = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 
            0, 
            intentBukaApp, 
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Layanan Aktif")
            .setContentText(pesan)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(pendingIntent)
            .setOngoing(true) // Notifikasi tidak bisa di-swipe hapus oleh pengguna
            .setPriority(NotificationCompat.PRIORITY_LOW) // Tidak berisik/getar setiap saat
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun buatNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Saluran Layanan Latar Belakang 24/7",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menjaga koneksi sinkronisasi latar belakang tetap aktif"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }
}