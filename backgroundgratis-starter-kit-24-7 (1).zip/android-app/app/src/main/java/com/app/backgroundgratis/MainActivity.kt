package com.app.backgroundgratis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val PERMISSION_REQUEST_CODE = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart = findViewById<Button>(R.id.btnStartService)
        val btnStop = findViewById<Button>(R.id.btnStopService)
        val btnBattery = findViewById<Button>(R.id.btnIgnoreBattery)
        val txtStatus = findViewById<TextView>(R.id.txtStatus)

        // 1. Minta izin Notifikasi (Wajib untuk Android 13+)
        mintaIzinNotifikasi()

        // 2. Tombol Mulai Service
        btnStart.setOnClickListener {
            val serviceIntent = Intent(this, LayananLatarBelakang::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            txtStatus.text = "Status: Layanan Foreground AKTIF (START_STICKY)"
            Toast.makeText(this, "Layanan Latar Belakang Dijalankan!", Toast.LENGTH_SHORT).show()
        }

        // 3. Tombol Hentikan Service
        btnStop.setOnClickListener {
            val serviceIntent = Intent(this, LayananLatarBelakang::class.java)
            stopService(serviceIntent)
            txtStatus.text = "Status: Layanan Dihentikan Manual"
            Toast.makeText(this, "Layanan Dihentikan.", Toast.LENGTH_SHORT).show()
        }

        // 4. Tombol Langkah Wajib: Pengecualian Baterai (Doze Mode Whitelist)
        btnBattery.setOnClickListener {
            bukaPengaturanPengecualianBaterai()
        }
    }

    private fun mintaIzinNotifikasi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    PERMISSION_REQUEST_CODE
                )
            }
        }
    }

    private fun bukaPengaturanPengecualianBaterai() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            val packageName = packageName

            // Cek apakah aplikasi sudah dikecualikan
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    // Dialog langsung minta "Jangan Optimalkan Baterai"
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    // Fallback jika OEM (Xiaomi/Samsung) memblokir intent langsung
                    val fallbackIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    startActivity(fallbackIntent)
                }
            } else {
                Toast.makeText(this, "Aplikasi SUDAH dikecualikan dari optimasi baterai (Aman)!", Toast.LENGTH_LONG).show()
            }
        }
    }
}